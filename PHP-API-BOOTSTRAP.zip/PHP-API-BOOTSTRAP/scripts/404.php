<?php
defined('CONTROL') or die('acesso invalido');
?>

<div class="container mt-5">
    <div class="row">
        <div class="col text-center">
            <h3 class="text-danger">Erro 404<br>Recurso não encontrado</h3>
        </div>
    </div>
</div>