<?php
defined('CONTROL') or die('acesso invalido');
?>
</body>
</html>