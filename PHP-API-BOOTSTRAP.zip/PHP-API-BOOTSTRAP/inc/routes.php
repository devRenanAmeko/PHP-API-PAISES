<?php

return[
    '404',
    'home',
    'country'
];